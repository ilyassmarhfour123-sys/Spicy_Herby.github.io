# spicy_herby
Static landing page for spicy_herby — Moroccan herbs, spices, cosmetics.

## How to use
1. Upload `index.html` and folders to your hosting.
2. Replace placeholder images in `images/` with real product photos.
3. Edit `index.html` to adjust text, links, and pricing.

## Hosting
- GitHub Pages
- Netlify
- Vercel
- Any standard web host
